# ARL Agent & Skills Pack — Akij Resource Limited

Shareable bundle for the Inventory Material Department (Demand & Supply).

## Contents

### Agents (`.opencode/agents/`)
- `cluster-inventory-lead.md` — **Cluster Inventory Lead (Bashir Alam)**. Primary leadership agent running the inventory cluster across 32+ SBUs, 300+ warehouses, 600+ suppliers. Control Tower, DIO/turnover, aging & obsolescence, negative-stock anomalies, PR pipeline, employee clearances, dashboards & reports.
- `inventory.md` — ARL Inventory Management Agent (stock, PR/GRN, aging, closing stock, dashboards).
- `inventory-intelligence.md` — AI Inventory Intelligence Agent (KPIs, forecasting, governance).

### Skills (`.opencode/skills/`)
| Skill | Purpose |
|---|---|
| connect-mcp | Manage MCP servers (MSSQL, Google Workspace, Playwright) |
| dio-monitoring | DIO tracking & trend monitoring across SBUs |
| inventory-aging | Obsolete / non-moving / slow-moving analysis |
| inventory-management | Stock levels, items, shipments, warehouse queries |
| inventory-turnover-ratios | Turnover & DIO efficiency analysis |
| otif-management | On-Time In-Full delivery performance |
| group-supply-chain | Group Supply Chain mandate, strategy & KPIs |
| team-building | Team structure, organogram, manpower, KPIs |
| arl-materials-management | ARL materials management workflows |
| gdrive-access | Google Drive access support |
| mis-reporting | MIS reporting support |
| procurement-management | Procurement process support |
| stock-analysis | Stock analysis workflows |

## Installation

1. Copy `agents/` files into: `<project>/.opencode/agents/`
2. Copy `skills/` folders into: `<project>/.opencode/skills/`
3. Restart opencode.
4. Select the agent from the Agent picker: **cluster-inventory-lead**.

## Notes
- Requires MCP servers configured in `opencode.json`:
  - `arl-inventory-control-tower` (remote, https://arl-control-tower.vercel.app/api/mcp)
  - `mssql-test-server` (DWH) / `mssql-datamart-server` (DataMart)
  - `google-workspace` (optional, for Sheets/Drive/Gmail)
- Database access is read-only. No DDL/DROP.
- Always filter `%Demo%` business units; use `isActive = 1`.
