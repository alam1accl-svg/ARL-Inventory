# ARL Inventory Control Tower — Contributor Guide

Welcome to the ARL Inventory Control Tower project. This guide explains how you can develop, add, and improve the Control Tower.

## What This Project Is

- **ARL Inventory Control Tower (MCP server)** — live dashboard data for Akij Resource Limited: closing stock by SBU, PR pending, aging buckets, DIO & turnover, employee clearances.
- Deployed on **Vercel** at `https://arl-control-tower.vercel.app/api/mcp`
- Data source: MSSQL DWH (203.202.241.211:1433, DB `DWH`)

## Project Structure

| Path | Purpose |
|---|---|
| `api/mcp.mjs` | MCP server entry — registers tools (`getControlTowerData`, `getInventoryAgentInsights`, `askInventoryAgent`) |
| `api/data.js` / `api/agent.js` | Serverless function endpoints |
| `lib/data.mjs` | Data layer — queries DWH (stock, PR, aging, DIO, clearance, warehouse-plant) |
| `lib/agent.mjs` | AI insights — health score, risks, predictions, recommendations |
| `lib/whplant.mjs` | Warehouse-plant mapping |
| `control_tower.html` | Main Control Tower dashboard (v2.0) |
| `dashboard.html`, `integrated_report.html`, `materials_dashboard.html`, `ibos_inventory_dashboard.html`, `index.html` | Supporting dashboards |
| `pending_clearances.html` | Employee clearance dashboard |
| `.opencode/` | Agent definitions + skills (for opencode users) |

## How to Contribute

### 1. Set up locally
```bash
npm install
# Set env vars (ask HOD for production values)
MSSQL_SERVER=203.202.241.211
MSSQL_PORT=1433
MSSQL_DATABASE=DWH
MSSQL_USER=mcp_user
MSSQL_PASSWORD=<ask HOD>
```

### 2. Workflow
1. Pick a task (improve a dashboard, add a KPI, fix a bug, add a new tool to the MCP server).
2. Edit the relevant file:
   - Dashboard UI/colors → `*.html`
   - New data/KPI → `lib/data.mjs` (SQL queries) + `api/mcp.mjs` (tool registration)
   - Insights/logic → `lib/agent.mjs`
3. Test locally with Node.js: `node -e "import('./lib/data.mjs').then(m=>m.fetchAll()).then(console.log)"`
4. Validate your HTML: check browser console for JS errors.
5. Submit your changes for review (share the modified files / commit to the shared repo).

### 3. Deployment (HOD approval required)
- The Control Tower deploys via **Vercel** from the repo. Only HOD / authorized admins trigger production deploys.
- Staging: deploy to a preview URL first, verify, then promote to production.

## Design Rules (must follow)

- **Palette (6 colors):** Black `#111111`, White `#FFFFFF`, Ocean Blue `#006994`, Brown `#8B5A2B`, Orange `#F97316`, Pink `#EC4899`.
- **Light themes** (white bg): positives = Ocean Blue, negatives = Black.
- **Dark themes** (dark bg): positives = White, negatives = Pink.
- **BDT formatting:** Cr for > 1 Cr, Lac for > 1 Lac.
- **Data hygiene:** always filter `%Demo%` from business unit names; always use `isActive = 1`.
- **WMS values** are cumulative transaction totals, not balances; GL `numAmount` is the current stock balance.
- **Akij Essentials Semi Finished Goods (-29.15T)** is a known systemic accounting anomaly — do not treat as real inventory.
- **Read-only database access.** No DDL/DROP.

## Security Rules

- **NEVER commit or share `opencode.json`** (contains DB credentials) or any `.env` files.
- Never log SQL connection strings or passwords.
- Treat G: Drive files as read-only reference.

## Questions
Contact: Bashir Alam, HOD — Inventory Material Department (Demand & Supply), Akij Resource Limited.
